import React from 'react';

const ActivityFeedModule = ({ logs }) => {
  
  // Вспомогательные функции для выбора цвета и иконки в зависимости от типа события
  const getLogColor = (type) => {
    switch(type) {
      case 'order': return 'rgba(59, 130, 246, 0.15)'; // Синий (Новый заказ)
      case 'success': return 'rgba(16, 185, 129, 0.15)'; // Зеленый (Выдано)
      case 'warning': return 'rgba(239, 68, 68, 0.15)'; // Красный (Стоп-лист)
      case 'info': return 'rgba(167, 139, 250, 0.15)'; // Фиолетовый (Настройки)
      default: return 'var(--btn-bg)';
    }
  };

  const getLogIcon = (type) => {
    switch(type) {
      case 'order': return '☕️';
      case 'success': return '✅';
      case 'warning': return '⚠️';
      case 'info': return '⚙️';
      default: return '📌';
    }
  };

  return (
    <div style={{ backgroundColor: 'var(--bg-card)', padding: '24px', borderRadius: '16px', boxShadow: '0 4px 6px -1px var(--shadow-color)', marginTop: '24px', flexGrow: 1, transition: 'all 0.3s ease' }}>
      <h2 style={{ margin: '0 0 20px 0', fontSize: '18px', color: 'var(--text-main)' }}>Журнал событий (Live)</h2>
      
      <div style={{ maxHeight: '400px', overflowY: 'auto', paddingRight: '8px' }}>
        {logs.length === 0 ? (
          <p style={{ color: 'var(--text-muted)', fontSize: '14px' }}>Событий пока нет...</p>
        ) : (
          logs.map((log, index) => (
            <div key={log.id} style={{ display: 'flex', gap: '16px', marginBottom: '20px', position: 'relative' }}>
              
              {/* Полоска (Таймлайн) соединяющая кружочки. У последнего элемента её нет */}
              {index !== logs.length - 1 && (
                <div style={{ position: 'absolute', left: '19px', top: '40px', bottom: '-20px', width: '2px', backgroundColor: 'var(--border-color)', zIndex: 1 }}></div>
              )}
              
              {/* Иконка события */}
              <div style={{ width: '40px', height: '40px', borderRadius: '50%', backgroundColor: getLogColor(log.type), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px', zIndex: 2, flexShrink: 0 }}>
                {getLogIcon(log.type)}
              </div>
              
              {/* Текст и время */}
              <div style={{ paddingTop: '2px' }}>
                <div style={{ fontSize: '14px', color: 'var(--text-main)', fontWeight: '600', marginBottom: '4px' }}>
                  {log.text}
                </div>
                <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: '500' }}>
                  {log.time}
                </div>
              </div>

            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ActivityFeedModule;