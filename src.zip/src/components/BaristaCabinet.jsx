import React from 'react';

const BaristaCabinet = ({ isOpen, onClose, baristaName, baristaStats = {}, salarySettings = {} }) => {
  if (!isOpen) return null;

  // Достаем статистику конкретного бариста
  const stats = baristaStats[baristaName] || { tips: 0, dessertsSold: 0, revenue: 0, ratingSum: 0, ratingCount: 0 };
  
  // Считаем примерную зарплату за день
  const estimatedSalary = Math.round((salarySettings.base || 1500) + (stats.revenue * ((salarySettings.percent || 5) / 100)));
  const avgRating = stats.ratingCount > 0 ? (stats.ratingSum / stats.ratingCount).toFixed(1) : '—';

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(15, 23, 42, 0.8)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', backdropFilter: 'blur(8px)', animation: 'fadeIn 0.2s ease' }}>
      <div style={{ backgroundColor: 'var(--bg-card)', width: '100%', maxWidth: '400px', borderRadius: '24px', overflow: 'hidden', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)', border: '1px solid var(--border-color)', animation: 'slideUp 0.3s ease' }}>
        
        {/* Шапка кабинета */}
        <div style={{ backgroundColor: '#3b82f6', padding: '32px 24px', color: 'white', textAlign: 'center', position: 'relative' }}>
          <button onClick={onClose} style={{ position: 'absolute', top: '16px', right: '16px', background: 'rgba(255,255,255,0.2)', border: 'none', color: 'white', width: '32px', height: '32px', borderRadius: '50%', cursor: 'pointer', fontWeight: 'bold' }}>✕</button>
          <div style={{ fontSize: '48px', marginBottom: '8px' }}>🧑‍🍳</div>
          <h2 style={{ margin: 0, fontSize: '24px', fontWeight: '800' }}>Привет, {baristaName}!</h2>
          <p style={{ margin: '4px 0 0 0', opacity: 0.9, fontSize: '14px' }}>Твои успехи за смену</p>
        </div>

        {/* Основные метрики */}
        <div style={{ padding: '24px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '24px' }}>
            
            <div style={{ backgroundColor: 'var(--bg-main)', padding: '16px', borderRadius: '16px', border: '1px solid var(--border-color)', textAlign: 'center' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: 'bold', marginBottom: '4px' }}>ЗАРПЛАТА</div>
              <div style={{ fontSize: '24px', fontWeight: '900', color: '#10b981' }}>{estimatedSalary} ₽</div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-main)', padding: '16px', borderRadius: '16px', border: '1px solid var(--border-color)', textAlign: 'center' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: 'bold', marginBottom: '4px' }}>ЧАЕВЫЕ</div>
              <div style={{ fontSize: '24px', fontWeight: '900', color: '#3b82f6' }}>{stats.tips} ₽</div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-main)', padding: '16px', borderRadius: '16px', border: '1px solid var(--border-color)', textAlign: 'center' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: 'bold', marginBottom: '4px' }}>ВЫРУЧКА</div>
              <div style={{ fontSize: '20px', fontWeight: '900', color: 'var(--text-main)' }}>{stats.revenue.toLocaleString('ru-RU')} ₽</div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-main)', padding: '16px', borderRadius: '16px', border: '1px solid var(--border-color)', textAlign: 'center' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: 'bold', marginBottom: '4px' }}>РЕЙТИНГ</div>
              <div style={{ fontSize: '20px', fontWeight: '900', color: '#f59e0b' }}>⭐ {avgRating}</div>
            </div>

          </div>

          {/* Мотивационный блок */}
          <div style={{ backgroundColor: 'rgba(245, 158, 11, 0.1)', padding: '16px', borderRadius: '12px', border: '1px solid rgba(245, 158, 11, 0.3)', display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ fontSize: '24px' }}>🧁</div>
            <div>
              <div style={{ fontSize: '14px', fontWeight: 'bold', color: 'var(--text-main)' }}>Продано десертов: {stats.dessertsSold}</div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '2px' }}>Предлагай круассан к каждому кофе, чтобы повысить средний чек!</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default BaristaCabinet;