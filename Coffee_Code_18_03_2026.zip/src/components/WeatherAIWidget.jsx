import React, { useState, useEffect } from 'react';

// Этот компонент полностью независим. Он сам запрашивает (или имитирует) погоду
// и выдает советы, не перегружая основную логику приложения.

const WeatherAIWidget = ({ allLowStock = [], baristaEfficiency = [], hourlyHeatmap = [] }) => {
  // Имитация данных о погоде (в реальном проекте тут был бы fetch к Яндекс.Погоде или OpenWeather)
  const [weather] = useState({ temp: '+12°C', condition: 'Дождь 🌧️', trend: 'Похолодание' });
  const [tips, setTips] = useState([]);

  useEffect(() => {
    const generatedTips = [];
    
    // Совет 1: Погода
    generatedTips.push({ 
      icon: '🌤', 
      text: `Погода за окном: ${weather.temp}, ${weather.condition}. ${weather.trend}. В такую погоду спрос на горячие напитки и выпечку вырастает на 20-30%.` 
    });
    
    // Совет 2: Склад
    if (allLowStock.length > 0) { 
      generatedTips.push({ icon: '📦', text: `Критичные остатки: ${allLowStock.map(i=>i.name).join(', ')}. Авто-закупка в панели Управляющего поможет быстро пополнить склад.` }); 
    } else { 
      generatedTips.push({ icon: '✅', text: `Склад в норме. Все ключевые ингредиенты в наличии.` }); 
    }
    
    // Совет 3: Команда
    if (baristaEfficiency.length > 1 && baristaEfficiency[0] && baristaEfficiency[0].avg > 0) { 
      const top = baristaEfficiency[0]; 
      const second = baristaEfficiency[1]; 
      if (top.avg - second.avg > 30) { 
        generatedTips.push({ icon: '👨‍🍳', text: `${top.name} продает лучше (${top.avg}₽ средний чек против ${second.avg}₽ у ${second.name}). Попросите ${second.name} активнее предлагать десерты!` }); 
      } else { 
        generatedTips.push({ icon: '🤝', text: `Команда работает отлично. Средний чек у бариста почти одинаковый.` }); 
      } 
    }
    
    // Совет 4: Загрузка
    if (hourlyHeatmap && hourlyHeatmap.length > 0) { 
      const peak = [...hourlyHeatmap].sort((a,b)=>b.count - a.count)[0]; 
      if (peak && peak.count > 0) { 
        generatedTips.push({ icon: '🔥', text: `Самый загруженный час: ${peak.hour}. Убедитесь, что в это время на смене работает опытный бариста.` }); 
      } 
    }

    setTips(generatedTips);
  }, [allLowStock, baristaEfficiency, hourlyHeatmap, weather]);

  return (
    <div style={{ backgroundColor: 'var(--bg-card)', padding: '24px', borderRadius: '16px', boxShadow: '0 0 15px rgba(59, 130, 246, 0.2)', marginBottom: '24px', border: '1px solid #3b82f6', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: '-50px', right: '-50px', width: '150px', height: '150px', background: 'radial-gradient(circle, rgba(59,130,246,0.2) 0%, transparent 70%)', borderRadius: '50%', pointerEvents: 'none' }}></div>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <h2 style={{ margin: '0', fontSize: '18px', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ fontSize: '24px', animation: 'float 3s infinite' }}>🤖</span> ИИ-Советник PRO
          <span style={{ fontSize: '10px', backgroundColor: '#3b82f6', color: 'white', padding: '2px 6px', borderRadius: '4px', textTransform: 'uppercase', letterSpacing: '1px' }}>Beta</span>
        </h2>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', backgroundColor: 'var(--bg-main)', padding: '6px 12px', borderRadius: '12px', fontSize: '14px', fontWeight: 'bold', color: 'var(--text-main)' }}>
          <span>{weather.condition}</span>
          <span style={{ color: '#3b82f6' }}>{weather.temp}</span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '16px' }}>
        {tips.map((tip, idx) => (
          <div key={idx} style={{ backgroundColor: 'var(--bg-main)', padding: '16px', borderRadius: '12px', display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
            <div style={{ fontSize: '20px' }}>{tip.icon}</div>
            <div style={{ fontSize: '14px', color: 'var(--text-main)', lineHeight: '1.4' }}>{tip.text}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WeatherAIWidget;